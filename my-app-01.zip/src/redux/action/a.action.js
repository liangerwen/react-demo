import { increment, decrement } from "../variable";

export function createIncrement(data) {
  return {
    type: increment,
    data,
  };
}

export function createDecrement(data) {
  return {
    type: decrement,
    data,
  };
}
