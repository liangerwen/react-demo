import {createStore} from 'redux'
import aReducer from './reducer/a.reducer.js'

export default createStore(aReducer);

//store.subscribe 检测store是否变化 参数为一个function

//store.dispatch  执行reducer方法  参数为封装的action