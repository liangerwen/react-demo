export const increment = "INCREMENT"
export const decrement = "DECREMENT"