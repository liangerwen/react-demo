import React from "react";
export default function B() {
    return (
      <>
        <h1>BBBBBBBBBB</h1>
        <h1>BBBBBBBBBB</h1>
        <h1>BBBBBBBBBB</h1>
        <h1>BBBBBBBBBB</h1>
        <h1>BBBBBBBBBB</h1>
        <h1>BBBBBBBBBB</h1>
        <h1>BBBBBBBBBB</h1>
      </>
    );
  }